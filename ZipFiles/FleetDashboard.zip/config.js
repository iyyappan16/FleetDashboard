var config = {}

config.endpoint = "https://hlsdb-tvk6dvklpv4ne.documents.azure.com:443/";
config.primaryKey = "1Ztoh9wuTcWFlQ4f5YbSkzfhAWc3nDUfO9sJFWoNsWDvR5xEsOHBaEAjaCYgxnqccdi4jDn9VfCExy6q8CAAIA==";

config.database = {
    "id": "HERE_API_LOGS"
};

config.container = {
    "id": "here_api_logs"
};



module.exports = config;